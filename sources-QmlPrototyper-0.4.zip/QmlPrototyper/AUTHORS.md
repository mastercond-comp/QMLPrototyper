# Authors
Автор приложения:
* Ponomarenko Stephan, февраль 2024
Создатель примера пустого приложения для ОС Аврора:
* Kirill Chuvilin, <k.chuvilin@omp.ru>
