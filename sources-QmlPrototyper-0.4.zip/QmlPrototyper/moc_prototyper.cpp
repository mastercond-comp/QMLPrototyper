/****************************************************************************
** Meta object code from reading C++ file 'prototyper.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "prototyper.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'prototyper.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Prototyper_t {
    QByteArrayData data[20];
    char stringdata0[302];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Prototyper_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Prototyper_t qt_meta_stringdata_Prototyper = {
    {
QT_MOC_LITERAL(0, 0, 10), // "Prototyper"
QT_MOC_LITERAL(1, 11, 17), // "returnFileCounter"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 15), // "createWorkFiles"
QT_MOC_LITERAL(4, 46, 13), // "pathDocuments"
QT_MOC_LITERAL(5, 60, 18), // "pathAppLocalFolder"
QT_MOC_LITERAL(6, 79, 29), // "saveComponentQMLdefaultfolder"
QT_MOC_LITERAL(7, 109, 15), // "componentsource"
QT_MOC_LITERAL(8, 125, 8), // "filename"
QT_MOC_LITERAL(9, 134, 24), // "savePageQMLdefaultfolder"
QT_MOC_LITERAL(10, 159, 16), // "saveComponentQML"
QT_MOC_LITERAL(11, 176, 11), // "savePageQML"
QT_MOC_LITERAL(12, 188, 17), // "loadQMLsourceFile"
QT_MOC_LITERAL(13, 206, 8), // "filepath"
QT_MOC_LITERAL(14, 215, 11), // "copySources"
QT_MOC_LITERAL(15, 227, 29), // "addTextTextAreaCursorPosition"
QT_MOC_LITERAL(16, 257, 8), // "position"
QT_MOC_LITERAL(17, 266, 4), // "text"
QT_MOC_LITERAL(18, 271, 6), // "string"
QT_MOC_LITERAL(19, 278, 23) // "qDebugOutputfromLogfile"

    },
    "Prototyper\0returnFileCounter\0\0"
    "createWorkFiles\0pathDocuments\0"
    "pathAppLocalFolder\0saveComponentQMLdefaultfolder\0"
    "componentsource\0filename\0"
    "savePageQMLdefaultfolder\0saveComponentQML\0"
    "savePageQML\0loadQMLsourceFile\0filepath\0"
    "copySources\0addTextTextAreaCursorPosition\0"
    "position\0text\0string\0qDebugOutputfromLogfile"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Prototyper[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x0a /* Public */,
       3,    0,   75,    2, 0x0a /* Public */,
       4,    0,   76,    2, 0x0a /* Public */,
       5,    0,   77,    2, 0x0a /* Public */,
       6,    2,   78,    2, 0x0a /* Public */,
       9,    2,   83,    2, 0x0a /* Public */,
      10,    2,   88,    2, 0x0a /* Public */,
      11,    2,   93,    2, 0x0a /* Public */,
      12,    1,   98,    2, 0x0a /* Public */,
      14,    0,  101,    2, 0x0a /* Public */,
      15,    3,  102,    2, 0x0a /* Public */,
      19,    0,  109,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::QString,
    QMetaType::Void,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    7,    8,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    7,    8,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    7,    8,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    7,    8,
    QMetaType::QString, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::QString, QMetaType::Int, QMetaType::QString, QMetaType::QString,   16,   17,   18,
    QMetaType::QString,

       0        // eod
};

void Prototyper::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Prototyper *_t = static_cast<Prototyper *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: { QString _r = _t->returnFileCounter();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 1: _t->createWorkFiles(); break;
        case 2: { QString _r = _t->pathDocuments();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 3: { QString _r = _t->pathAppLocalFolder();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 4: _t->saveComponentQMLdefaultfolder((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 5: _t->savePageQMLdefaultfolder((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 6: _t->saveComponentQML((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 7: _t->savePageQML((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 8: { QString _r = _t->loadQMLsourceFile((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 9: _t->copySources(); break;
        case 10: { QString _r = _t->addTextTextAreaCursorPosition((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 11: { QString _r = _t->qDebugOutputfromLogfile();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObject Prototyper::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Prototyper.data,
      qt_meta_data_Prototyper,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Prototyper::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Prototyper::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Prototyper.stringdata0))
        return static_cast<void*>(const_cast< Prototyper*>(this));
    return QObject::qt_metacast(_clname);
}

int Prototyper::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
