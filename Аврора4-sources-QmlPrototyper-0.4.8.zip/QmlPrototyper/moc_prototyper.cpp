/****************************************************************************
** Meta object code from reading C++ file 'prototyper.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "prototyper.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'prototyper.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Prototyper_t {
    QByteArrayData data[36];
    char stringdata0[578];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Prototyper_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Prototyper_t qt_meta_stringdata_Prototyper = {
    {
QT_MOC_LITERAL(0, 0, 10), // "Prototyper"
QT_MOC_LITERAL(1, 11, 26), // "reloadCurrentFileNameCover"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 17), // "returnFileCounter"
QT_MOC_LITERAL(4, 57, 15), // "createWorkFiles"
QT_MOC_LITERAL(5, 73, 13), // "pathDocuments"
QT_MOC_LITERAL(6, 87, 18), // "pathAppLocalFolder"
QT_MOC_LITERAL(7, 106, 29), // "saveComponentQMLdefaultfolder"
QT_MOC_LITERAL(8, 136, 15), // "componentsource"
QT_MOC_LITERAL(9, 152, 8), // "filename"
QT_MOC_LITERAL(10, 161, 24), // "savePageQMLdefaultfolder"
QT_MOC_LITERAL(11, 186, 16), // "saveComponentQML"
QT_MOC_LITERAL(12, 203, 11), // "savePageQML"
QT_MOC_LITERAL(13, 215, 17), // "loadQMLsourceFile"
QT_MOC_LITERAL(14, 233, 8), // "filepath"
QT_MOC_LITERAL(15, 242, 11), // "copySources"
QT_MOC_LITERAL(16, 254, 29), // "addTextTextAreaCursorPosition"
QT_MOC_LITERAL(17, 284, 8), // "position"
QT_MOC_LITERAL(18, 293, 4), // "text"
QT_MOC_LITERAL(19, 298, 6), // "string"
QT_MOC_LITERAL(20, 305, 23), // "qDebugOutputfromLogfile"
QT_MOC_LITERAL(21, 329, 14), // "linesCountText"
QT_MOC_LITERAL(22, 344, 8), // "edittext"
QT_MOC_LITERAL(23, 353, 24), // "linesCountTextfromEditor"
QT_MOC_LITERAL(24, 378, 10), // "linescount"
QT_MOC_LITERAL(25, 389, 19), // "soderzhanieNalichie"
QT_MOC_LITERAL(26, 409, 15), // "soderzhanieList"
QT_MOC_LITERAL(27, 425, 18), // "soderzhanieListMap"
QT_MOC_LITERAL(28, 444, 21), // "positionForLineNumber"
QT_MOC_LITERAL(29, 466, 10), // "lineNumber"
QT_MOC_LITERAL(30, 477, 18), // "physicalScreenSize"
QT_MOC_LITERAL(31, 496, 22), // "returnFileNameFromPath"
QT_MOC_LITERAL(32, 519, 11), // "filepathurl"
QT_MOC_LITERAL(33, 531, 17), // "workfilenamewrite"
QT_MOC_LITERAL(34, 549, 11), // "filenamestr"
QT_MOC_LITERAL(35, 561, 16) // "workfilenameread"

    },
    "Prototyper\0reloadCurrentFileNameCover\0"
    "\0returnFileCounter\0createWorkFiles\0"
    "pathDocuments\0pathAppLocalFolder\0"
    "saveComponentQMLdefaultfolder\0"
    "componentsource\0filename\0"
    "savePageQMLdefaultfolder\0saveComponentQML\0"
    "savePageQML\0loadQMLsourceFile\0filepath\0"
    "copySources\0addTextTextAreaCursorPosition\0"
    "position\0text\0string\0qDebugOutputfromLogfile\0"
    "linesCountText\0edittext\0"
    "linesCountTextfromEditor\0linescount\0"
    "soderzhanieNalichie\0soderzhanieList\0"
    "soderzhanieListMap\0positionForLineNumber\0"
    "lineNumber\0physicalScreenSize\0"
    "returnFileNameFromPath\0filepathurl\0"
    "workfilenamewrite\0filenamestr\0"
    "workfilenameread"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Prototyper[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,  130,    2, 0x0a /* Public */,
       4,    0,  131,    2, 0x0a /* Public */,
       5,    0,  132,    2, 0x0a /* Public */,
       6,    0,  133,    2, 0x0a /* Public */,
       7,    2,  134,    2, 0x0a /* Public */,
      10,    2,  139,    2, 0x0a /* Public */,
      11,    2,  144,    2, 0x0a /* Public */,
      12,    2,  149,    2, 0x0a /* Public */,
      13,    1,  154,    2, 0x0a /* Public */,
      15,    0,  157,    2, 0x0a /* Public */,
      16,    3,  158,    2, 0x0a /* Public */,
      20,    0,  165,    2, 0x0a /* Public */,
      21,    1,  166,    2, 0x0a /* Public */,
      23,    1,  169,    2, 0x0a /* Public */,
      25,    1,  172,    2, 0x0a /* Public */,
      26,    1,  175,    2, 0x0a /* Public */,
      27,    1,  178,    2, 0x0a /* Public */,
      28,    2,  181,    2, 0x0a /* Public */,
      30,    0,  186,    2, 0x0a /* Public */,
      31,    1,  187,    2, 0x0a /* Public */,
      33,    1,  190,    2, 0x0a /* Public */,
      35,    0,  193,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::QString,
    QMetaType::Void,
    QMetaType::QString,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    8,    9,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    8,    9,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    8,    9,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    8,    9,
    QMetaType::QString, QMetaType::QString,   14,
    QMetaType::Void,
    QMetaType::QString, QMetaType::Int, QMetaType::QString, QMetaType::QString,   17,   18,   19,
    QMetaType::QString,
    QMetaType::QString, QMetaType::QString,   22,
    QMetaType::QString, QMetaType::QString,   24,
    QMetaType::Bool, QMetaType::QString,   22,
    QMetaType::QString, QMetaType::QString,   22,
    QMetaType::QVariantMap, QMetaType::QString,   22,
    QMetaType::QString, QMetaType::QString, QMetaType::QString,   22,   29,
    QMetaType::QReal,
    QMetaType::QString, QMetaType::QString,   32,
    QMetaType::Void, QMetaType::QString,   34,
    QMetaType::QString,

       0        // eod
};

void Prototyper::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Prototyper *_t = static_cast<Prototyper *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->reloadCurrentFileNameCover(); break;
        case 1: { QString _r = _t->returnFileCounter();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 2: _t->createWorkFiles(); break;
        case 3: { QString _r = _t->pathDocuments();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 4: { QString _r = _t->pathAppLocalFolder();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 5: _t->saveComponentQMLdefaultfolder((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 6: _t->savePageQMLdefaultfolder((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 7: _t->saveComponentQML((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 8: _t->savePageQML((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 9: { QString _r = _t->loadQMLsourceFile((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 10: _t->copySources(); break;
        case 11: { QString _r = _t->addTextTextAreaCursorPosition((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 12: { QString _r = _t->qDebugOutputfromLogfile();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 13: { QString _r = _t->linesCountText((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 14: { QString _r = _t->linesCountTextfromEditor((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 15: { bool _r = _t->soderzhanieNalichie((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 16: { QString _r = _t->soderzhanieList((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 17: { QVariantMap _r = _t->soderzhanieListMap((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QVariantMap*>(_a[0]) = _r; }  break;
        case 18: { QString _r = _t->positionForLineNumber((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 19: { qreal _r = _t->physicalScreenSize();
            if (_a[0]) *reinterpret_cast< qreal*>(_a[0]) = _r; }  break;
        case 20: { QString _r = _t->returnFileNameFromPath((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 21: _t->workfilenamewrite((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 22: { QString _r = _t->workfilenameread();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Prototyper::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Prototyper::reloadCurrentFileNameCover)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject Prototyper::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Prototyper.data,
      qt_meta_data_Prototyper,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Prototyper::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Prototyper::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Prototyper.stringdata0))
        return static_cast<void*>(const_cast< Prototyper*>(this));
    return QObject::qt_metacast(_clname);
}

int Prototyper::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}

// SIGNAL 0
void Prototyper::reloadCurrentFileNameCover()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
