#ifndef PROTOTYPER_H
#define PROTOTYPER_H

#include <QObject>
#include <QString>
#include <QStandardPaths>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QTextStream>
#include <QIODevice>
#include <QQmlEngine>
#include <QDateTime>

#include <QScreen>
#include <QtCore/qmath.h>

#include <QVariantMap>

#define APP_SOURCES "/usr/share/ru.mastercond.QmlPrototyper/qml/pages/sources/sources-QmlPrototyper-0.4.8.zip"
#define APP_SOURCES_OUTPUT QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation)+"/sources-QmlPrototyper-0.4.8.zip"

class Prototyper: public QObject
{
    Q_OBJECT

public:
    explicit Prototyper(QObject *parent = 0);
    static int FILECOUNTERPREVIEW;
    static QString CURRENTWORKFILE; //имя текущего файла, открытого или созданного в редакторе

public slots:
    QString returnFileCounter(); //возвращает значение глобальной переменной для перехода к qml-файлу

    void createWorkFiles(); //создать в папке приложения AppLocalDataLocation пустые файлы error_log.txt, component_preview.qml, page_preview.qml

    QString pathDocuments(); //возвращает путь до папки Документы для использования пути в QML

    QString pathAppLocalFolder(); //возвращает путь до папки  кэша приложения для использования пути в QML

    void saveComponentQMLdefaultfolder(QString componentsource, QString filename); //сохраняет правленный файл в папке Документы/QML прототипы/ и перезаписывает component_preview_XXXX.qml в папке приложения для его последующего просмотра

    void savePageQMLdefaultfolder(QString componentsource, QString filename); //сохраняет правленный файл в папке Документы/QML прототипы/ и перезаписывает component_page_XXXX.qml в папке приложения для его последующего просмотра

    void saveComponentQML(QString componentsource, QString filename); //сохраняет правленный файл в папке и перезаписывает component_preview_XXXX.qml в папке приложения для его последующего просмотра

    void savePageQML(QString componentsource, QString filename); //сохраняет правленный файл в папке и перезаписывает component_page_XXXX.qml в папке приложения для его последующего просмотра

    QString loadQMLsourceFile(QString filepath); //возвращает содержимое QML файла в виде строки для отображения в TextArea

    void copySources(); //скопировать файл исходных кодов приложения в папку Документы

    QString addTextTextAreaCursorPosition(int position, QString text, QString string); // добавляет подстроку string в нужное место строки text (где курсор) - для дополнения QML кода шаблонами

    QString qDebugOutputfromLogfile(); //открывает лог-файл, созданный в main.cpp и возвращает его содержимое строкой для отображения в консоли приложения

    QString linesCountText(QString edittext); //возвращает количество строк в передаваемой переменной для реализации отображения номеров строк (передается весь текст из TextArea) - для предыдущих версии QMLPrototyper

    QString linesCountTextfromEditor(QString linescount); //возвращает количество строк в передаваемой переменной для реализации отображения номеров строк (сюда передается textarea._editor.lineCount)

    bool soderzhanieNalichie (QString edittext); //возвращает true, если в передаваемой переменной содержится //#Содержание и //#Закладка

    QString soderzhanieList(QString edittext); //возвращает ряд в csv-формате [Наименование закладки 1;Строка 1; Наименование закладки 2; Строка 2.....] - для предыдущих версии QMLPrototyper

    QVariantMap soderzhanieListMap(QString edittext); //возвращает QVariantMap с закладками и позицией закладки для использования в QML и возвращает QVariantMap, который используется для заполнения ListView с закладками

    QString positionForLineNumber(QString edittext, QString lineNumber); //возвращает количество символов до передаваемого номера строки в переменной edittext для установки курсора в начало этой строки (работа с Закладками)

    qreal physicalScreenSize(); //возвращает физический размер диагонали экрана - необходимо в QML для корректировки элементов для планшетов 8"

    QString returnFileNameFromPath (QString filepathurl); //возвращает имя файла из строки с путем к файлу

    void workfilenamewrite(QString filenamestr); //записать имя файла в статическую переменную CURRENTWORKFILE

    QString workfilenameread(); //получить имя файла из статической переменной CURRENTWORKFILE


signals:

     void reloadCurrentFileNameCover(); //отправить сигнал для отображения на обложке нового имени файла

};

#endif // PROTOTYPER_H
